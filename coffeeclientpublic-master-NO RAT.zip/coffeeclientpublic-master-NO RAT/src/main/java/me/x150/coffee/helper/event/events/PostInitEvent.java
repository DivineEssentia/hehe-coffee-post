package me.x150.coffee.helper.event.events;

import me.x150.coffee.helper.event.events.base.NonCancellableEvent;

public class PostInitEvent extends NonCancellableEvent {

}
