package me.x150.coffee.feature.gui;

public interface FastTickable {

    void onFastTick();
}
