# coffee clinet
## installing
You need:
- fabric
- the jar
- not meteor because thats shit
- no fabric api is needed but you can still use it

1. make new instance
2. mods folder
3. put the jar in the mods folder
4. done